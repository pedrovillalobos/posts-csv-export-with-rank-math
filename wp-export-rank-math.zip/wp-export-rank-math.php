<?php
/**
 * Plugin Name: WP Export Rank Math
 * Plugin URI: https://github.com/pedrovillalobos/wp-export-rank-math
 * Description: Export WordPress posts with Rank Math SEO data to CSV format including scores, keywords, structured data, and link information.
 * Version: 1.0.10
 * Author: Pedro Villalobos
 * Author URI: https://villalobos.com.br
 * License: GPL v2 or later
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Text Domain: wp-export-rank-math
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WPERM_VERSION', '1.0.10');
define('WPERM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPERM_PLUGIN_PATH', plugin_dir_path(__FILE__));

/**
 * Main plugin class
 */
class WP_Export_Rank_Math {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_wperm_export_csv', array($this, 'handle_export_csv'));
        add_action('wp_ajax_nopriv_wperm_export_csv', array($this, 'handle_export_csv'));
        add_action('wp_ajax_wperm_debug_data', array($this, 'handle_debug_data'));
        add_action('wp_ajax_nopriv_wperm_debug_data', array($this, 'handle_debug_data'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        load_plugin_textdomain('wp-export-rank-math', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_management_page(
            __('Export Rank Math Data', 'wp-export-rank-math'),
            __('Export Rank Math', 'wp-export-rank-math'),
            'manage_options',
            'wp-export-rank-math',
            array($this, 'admin_page')
        );
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'tools_page_wp-export-rank-math') {
            return;
        }
        
        wp_enqueue_script(
            'wperm-admin',
            WPERM_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            WPERM_VERSION,
            true
        );
        
        wp_localize_script('wperm-admin', 'wperm_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wperm_export_nonce'),
            'strings' => array(
                'exporting' => __('Exporting...', 'wp-export-rank-math'),
                'export_complete' => __('Export complete!', 'wp-export-rank-math'),
                'export_error' => __('Export failed. Please try again.', 'wp-export-rank-math')
            )
        ));
        
        wp_enqueue_style(
            'wperm-admin',
            WPERM_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            WPERM_VERSION
        );
    }
    
    /**
     * Admin page content
     */
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Export Rank Math Data', 'wp-export-rank-math'); ?></h1>
            
            <div class="wperm-container">
                <div class="wperm-card">
                    <h2><?php _e('Export Settings', 'wp-export-rank-math'); ?></h2>
                    
                    <form id="wperm-export-form">
                        <div class="notice notice-info" style="margin-bottom: 20px;">
                            <p><?php _e('If you don\'t choose a start and end date, it\'ll default to export everything.', 'wp-export-rank-math'); ?></p>
                        </div>
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="post_type"><?php _e('Post Type', 'wp-export-rank-math'); ?></label>
                                </th>
                                <td>
                                    <select name="post_type" id="post_type">
                                        <option value="post"><?php _e('Posts', 'wp-export-rank-math'); ?></option>
                                        <option value="page"><?php _e('Pages', 'wp-export-rank-math'); ?></option>
                                        <option value="all"><?php _e('All Post Types', 'wp-export-rank-math'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="post_status"><?php _e('Post Status', 'wp-export-rank-math'); ?></label>
                                </th>
                                <td>
                                    <select name="post_status" id="post_status">
                                        <option value="publish"><?php _e('Published', 'wp-export-rank-math'); ?></option>
                                        <option value="draft"><?php _e('Draft', 'wp-export-rank-math'); ?></option>
                                        <option value="pending"><?php _e('Pending Review', 'wp-export-rank-math'); ?></option>
                                        <option value="all"><?php _e('All Statuses', 'wp-export-rank-math'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="date_from"><?php _e('Date From', 'wp-export-rank-math'); ?></label>
                                </th>
                                <td>
                                    <input type="date" name="date_from" id="date_from" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="date_to"><?php _e('Date To', 'wp-export-rank-math'); ?></label>
                                </th>
                                <td>
                                    <input type="date" name="date_to" id="date_to" />
                                </td>
                            </tr>
                        </table>
                        
                        <p class="submit">
                            <button type="submit" class="button button-primary" id="wperm-export-btn">
                                <?php _e('Export to CSV', 'wp-export-rank-math'); ?>
                            </button>
                            <span class="spinner" style="float: none; margin-left: 10px;"></span>
                        </p>
                        
                        <p>
                            <button type="button" class="button button-secondary" id="wperm-debug-btn">
                                <?php _e('Debug Rank Math Data', 'wp-export-rank-math'); ?>
                            </button>
                            <small style="margin-left: 10px; color: #666;">
                                <?php _e('Click to see what Rank Math data is available for a sample post', 'wp-export-rank-math'); ?>
                            </small>
                        </p>
                    </form>
                </div>
                
                <div class="wperm-card">
                    <h2><?php _e('Export Information', 'wp-export-rank-math'); ?></h2>
                    <p><?php _e('This export will include the following data:', 'wp-export-rank-math'); ?></p>
                    <ul>
                        <li><?php _e('Post Title', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Post URL', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Author', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Status (Published, Draft, etc.)', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Last Edit Date', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Categories', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Rank Math Score', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Rank Math Main Keyword', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Rank Math Additional Keywords', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Rank Math Structured Data Type', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Rank Math Internal Links', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Rank Math External Links', 'wp-export-rank-math'); ?></li>
                        <li><?php _e('Rank Math Incoming Links', 'wp-export-rank-math'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Handle CSV export via AJAX
     */
    public function handle_export_csv() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'wperm_export_nonce')) {
            wp_die(__('Security check failed.', 'wp-export-rank-math'));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to perform this action.', 'wp-export-rank-math'));
        }
        
        // Get export parameters
        $post_type = sanitize_text_field($_POST['post_type']);
        $post_status = sanitize_text_field($_POST['post_status']);
        $date_from = sanitize_text_field($_POST['date_from']);
        $date_to = sanitize_text_field($_POST['date_to']);
        
        // Generate CSV
        $csv_data = $this->generate_csv_data($post_type, $post_status, $date_from, $date_to);
        
        if ($csv_data === false) {
            wp_send_json_error(__('Failed to generate CSV data.', 'wp-export-rank-math'));
        }
        
        // Set headers for file download
        $filename = 'rank-math-export-' . date('Y-m-d-H-i-s') . '.csv';
        
        wp_send_json_success(array(
            'csv_data' => $csv_data,
            'filename' => $filename
        ));
    }
    
    /**
     * Handle debug data request via AJAX
     */
    public function handle_debug_data() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'wperm_export_nonce')) {
            wp_die(__('Security check failed.', 'wp-export-rank-math'));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to perform this action.', 'wp-export-rank-math'));
        }
        
        // Get a sample post to debug
        $posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => 1
        ));
        
        if (empty($posts)) {
            wp_send_json_error(__('No posts found to debug.', 'wp-export-rank-math'));
        }
        
        $post = $posts[0];
        $debug_data = $this->debug_rank_math_data($post->ID);
        
        wp_send_json_success(array(
            'post_title' => $post->post_title,
            'post_id' => $post->ID,
            'debug_data' => $debug_data
        ));
    }
    
    /**
     * Generate CSV data
     */
    private function generate_csv_data($post_type, $post_status, $date_from, $date_to) {
        global $wpdb;
        
        // Build query
        $where_conditions = array();
        $where_values = array();
        
        // Post type condition
        if ($post_type !== 'all') {
            $where_conditions[] = 'p.post_type = %s';
            $where_values[] = $post_type;
        }
        
        // Post status condition
        if ($post_status !== 'all') {
            $where_conditions[] = 'p.post_status = %s';
            $where_values[] = $post_status;
        }
        
        // Date conditions - only apply if both dates are specified
        if (!empty($date_from) && !empty($date_to)) {
            $where_conditions[] = 'p.post_modified >= %s';
            $where_values[] = $date_from . ' 00:00:00';
            
            $where_conditions[] = 'p.post_modified <= %s';
            $where_values[] = $date_to . ' 23:59:59';
        } elseif (!empty($date_from)) {
            // Only from date specified
            $where_conditions[] = 'p.post_modified >= %s';
            $where_values[] = $date_from . ' 00:00:00';
        } elseif (!empty($date_to)) {
            // Only to date specified
            $where_conditions[] = 'p.post_modified <= %s';
            $where_values[] = $date_to . ' 23:59:59';
        }
        // If no dates specified, export all posts (no date filter applied)
        
        $where_clause = '';
        if (!empty($where_conditions)) {
            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
        }
        
        // Build the main query
        $query = "
            SELECT 
                p.ID,
                p.post_title,
                p.post_status,
                p.post_modified,
                p.post_author,
                p.post_type,
                u.display_name as author_name
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->users} u ON p.post_author = u.ID
            {$where_clause}
            ORDER BY p.post_modified DESC
        ";
        
        if (!empty($where_values)) {
            $query = $wpdb->prepare($query, $where_values);
        }
        
        $posts = $wpdb->get_results($query);
        
        if (empty($posts)) {
            return false;
        }
        
        // Prepare CSV data
        $csv_data = array();
        
        // CSV headers
        $headers = array(
            'Post Title',
            'Post URL',
            'Author',
            'Status',
            'Last Edit Date',
            'Categories',
            'Rank Math Score',
            'Rank Math Main Keyword',
            'Rank Math Structured Data Type',
            'Rank Math Internal Links',
            'Rank Math External Links',
            'Rank Math Incoming Links'
        );
        
        $csv_data[] = $headers;
        
        // Process each post
        foreach ($posts as $post) {
            $row = array();
            
            // Post Title
            $row[] = $this->escape_csv_value($post->post_title);
            
            // Post URL
            $row[] = get_permalink($post->ID);
            
            // Author
            $row[] = $this->escape_csv_value($post->author_name);
            
            // Status
            $row[] = $this->escape_csv_value($post->post_status);
            
            // Last Edit Date
            $row[] = $this->escape_csv_value($post->post_modified);
            
            // Categories
            $categories = get_the_category($post->ID);
            $category_names = array();
            foreach ($categories as $category) {
                $category_names[] = $category->name;
            }
            $row[] = $this->escape_csv_value(implode(', ', $category_names));
            
            // Rank Math Score - try multiple possible meta keys
            $rank_math_score = $this->get_rank_math_score($post->ID);
            $row[] = $this->escape_csv_value($rank_math_score);
            
            // Rank Math Main Keyword - try multiple possible meta keys
            $rank_math_keyword = $this->get_rank_math_keyword($post->ID);
            $row[] = $this->escape_csv_value($rank_math_keyword);
            
            // Rank Math Structured Data Type - try multiple possible meta keys
            $rank_math_schema = $this->get_rank_math_schema($post->ID);
            $row[] = $this->escape_csv_value($rank_math_schema);
            
            // Rank Math Internal Links - try multiple possible meta keys
            $rank_math_internal_links = $this->get_rank_math_internal_links($post->ID);
            $row[] = $this->escape_csv_value($rank_math_internal_links);
            
            // Rank Math External Links - try multiple possible meta keys
            $rank_math_external_links = $this->get_rank_math_external_links($post->ID);
            $row[] = $this->escape_csv_value($rank_math_external_links);
            
            // Rank Math Incoming Links - try multiple possible meta keys
            $rank_math_incoming_links = $this->get_rank_math_incoming_links($post->ID);
            $row[] = $this->escape_csv_value($rank_math_incoming_links);
            
            $csv_data[] = $row;
        }
        
        // Convert to CSV string
        $csv_string = '';
        foreach ($csv_data as $row) {
            $csv_string .= implode(',', $row) . "\n";
        }
        
        return $csv_string;
    }
    
    /**
     * Get Rank Math score from analytics table with fallbacks
     */
    private function get_rank_math_score($post_id) {
        global $wpdb;
        
        // First try the Rank Math analytics table
        $table_name = $wpdb->prefix . 'rank_math_analytics_objects';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name) {
            $query = $wpdb->prepare("
                SELECT seo_score 
                FROM {$table_name} 
                WHERE object_id = %d
            ", $post_id);
            
            $score = $wpdb->get_var($query);
            if ($score !== null && $score !== '') {
                return $score;
            }
        }
        
        // Fallback to post meta
        $score_keys = array(
            'rank_math_seo_score',
            'rank_math_score',
            'rank_math_analytics_score',
            'rank_math_advanced_seo_score'
        );
        
        foreach ($score_keys as $key) {
            $score = get_post_meta($post_id, $key, true);
            if (!empty($score)) {
                return $score;
            }
        }
        
        return '';
    }
    
    /**
     * Get Rank Math keyword from analytics table with fallbacks
     */
    private function get_rank_math_keyword($post_id) {
        global $wpdb;
        
        // First try the Rank Math analytics table
        $table_name = $wpdb->prefix . 'rank_math_analytics_objects';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name) {
            $query = $wpdb->prepare("
                SELECT primary_key 
                FROM {$table_name} 
                WHERE object_id = %d
            ", $post_id);
            
            $keyword = $wpdb->get_var($query);
            if (!empty($keyword)) {
                // If it contains commas, take only the first keyword
                $keywords = explode(',', $keyword);
                return trim($keywords[0]);
            }
        }
        
        // Fallback to post meta
        $keyword_keys = array(
            'rank_math_focus_keyword',
            'rank_math_keyword',
            'rank_math_primary_keyword',
            'rank_math_target_keyword'
        );
        
        foreach ($keyword_keys as $key) {
            $keyword = get_post_meta($post_id, $key, true);
            if (!empty($keyword)) {
                // If it contains commas, take only the first keyword
                $keywords = explode(',', $keyword);
                return trim($keywords[0]);
            }
        }
        
        return '';
    }
    
    /**
     * Get Rank Math additional keywords from analytics table with fallbacks
     */
    private function get_rank_math_additional_keywords($post_id) {
        global $wpdb;
        
        // First try the Rank Math analytics table
        $table_name = $wpdb->prefix . 'rank_math_analytics_objects';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name) {
            $query = $wpdb->prepare("
                SELECT primary_key 
                FROM {$table_name} 
                WHERE object_id = %d
            ", $post_id);
            
            $full_keyword = $wpdb->get_var($query);
            if (!empty($full_keyword)) {
                $keywords = explode(',', $full_keyword);
                if (count($keywords) > 1) {
                    // Remove the first keyword and return the rest
                    array_shift($keywords);
                    return trim(implode(', ', $keywords));
                }
            }
        }
        
        // Fallback to post meta
        $keyword_keys = array(
            'rank_math_focus_keyword',
            'rank_math_keyword',
            'rank_math_primary_keyword',
            'rank_math_target_keyword'
        );
        
        foreach ($keyword_keys as $key) {
            $full_keyword = get_post_meta($post_id, $key, true);
            if (!empty($full_keyword)) {
                $keywords = explode(',', $full_keyword);
                if (count($keywords) > 1) {
                    // Remove the first keyword and return the rest
                    array_shift($keywords);
                    return trim(implode(', ', $keywords));
                }
            }
        }
        
        // Try to get additional keywords from Rank Math secondary field
        $additional_keywords = get_post_meta($post_id, 'rank_math_focus_keyword_secondary', true);
        if (!empty($additional_keywords)) {
            return $additional_keywords;
        }
        
        return '';
    }
    
    /**
     * Get Rank Math schema type from analytics table with fallbacks
     */
    private function get_rank_math_schema($post_id) {
        global $wpdb;
        
        // First try the Rank Math analytics table
        $table_name = $wpdb->prefix . 'rank_math_analytics_objects';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name) {
            $query = $wpdb->prepare("
                SELECT schemas_in_use 
                FROM {$table_name} 
                WHERE object_id = %d
            ", $post_id);
            
            $schema = $wpdb->get_var($query);
            if (!empty($schema)) {
                return $this->format_schema_type($schema);
            }
        }
        
        // Fallback to post meta if not found in analytics table
        $schema_type = get_post_meta($post_id, 'rank_math_rich_snippet_type', true);
        if (!empty($schema_type)) {
            return $this->format_schema_type($schema_type);
        }
        
        // Try alternative meta keys
        $schema_keys = array(
            'rank_math_schema_type',
            'rank_math_structured_data_type'
        );
        
        foreach ($schema_keys as $key) {
            $schema = get_post_meta($post_id, $key, true);
            if (!empty($schema)) {
                return $this->format_schema_type($schema);
            }
        }
        
        // Only use Rank Math options if they are explicitly set and not 'off'
        $rank_math_options = get_option('rank_math_options', array());
        $post_type = get_post_type($post_id);
        
        if ($post_type === 'post' && !empty($rank_math_options['titles']['pt_post_default_rich_snippet']) && $rank_math_options['titles']['pt_post_default_rich_snippet'] !== 'off') {
            return $this->format_schema_type($rank_math_options['titles']['pt_post_default_rich_snippet']);
        }
        
        if ($post_type === 'page' && !empty($rank_math_options['titles']['pt_page_default_rich_snippet']) && $rank_math_options['titles']['pt_page_default_rich_snippet'] !== 'off') {
            return $this->format_schema_type($rank_math_options['titles']['pt_page_default_rich_snippet']);
        }
        
        // Try general default only if it's not 'off'
        if (!empty($rank_math_options['titles']['pt_default_rich_snippet']) && $rank_math_options['titles']['pt_default_rich_snippet'] !== 'off') {
            return $this->format_schema_type($rank_math_options['titles']['pt_default_rich_snippet']);
        }
        
        // Return empty if no schema is configured
        return '';
    }
    
    /**
     * Format schema type for display
     */
    private function format_schema_type($schema_type) {
        // Map common schema types to display names
        $schema_map = array(
            'article' => 'Article',
            'webpage' => 'WebPage',
            'blogposting' => 'Blog Posting',
            'newsarticle' => 'News Article',
            'product' => 'Product',
            'review' => 'Review',
            'localbusiness' => 'Local Business',
            'organization' => 'Organization',
            'person' => 'Person',
            'event' => 'Event',
            'recipe' => 'Recipe',
            'video' => 'Video',
            'book' => 'Book',
            'course' => 'Course',
            'faq' => 'FAQ',
            'howto' => 'How To',
            'jobposting' => 'Job Posting',
            'movie' => 'Movie',
            'music' => 'Music',
            'restaurant' => 'Restaurant',
            'service' => 'Service',
            'softwareapplication' => 'Software Application',
            'website' => 'Website'
        );
        
        $schema_type = strtolower($schema_type);
        
        // Check if we have a mapping for this type
        if (isset($schema_map[$schema_type])) {
            return $schema_map[$schema_type];
        }
        
        // Return original if no mapping found
        return ucfirst($schema_type);
    }
    
    /**
     * Get Rank Math internal links from database table with fallbacks
     */
    private function get_rank_math_internal_links($post_id) {
        global $wpdb;
        
        // First try the Rank Math internal meta table
        $table_name = $wpdb->prefix . 'rank_math_internal_meta';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name) {
            $query = $wpdb->prepare("
                SELECT internal_link_count 
                FROM {$table_name} 
                WHERE object_id = %d
            ", $post_id);
            
            $internal_links = $wpdb->get_var($query);
            if ($internal_links !== null && $internal_links !== '') {
                return $internal_links;
            }
        }
        
        // Fallback to post meta
        $link_keys = array(
            'rank_math_internal_links',
            'rank_math_internal_link_count',
            'rank_math_internal_links_count',
            'rank_math_inlinks',
            'rank_math_internal_backlinks'
        );
        
        foreach ($link_keys as $key) {
            $links = get_post_meta($post_id, $key, true);
            if ($links !== null && $links !== '') {
                return $links;
            }
        }
        
        return 0;
    }
    
    /**
     * Get Rank Math external links from database table with fallbacks
     */
    private function get_rank_math_external_links($post_id) {
        global $wpdb;
        
        // First try the Rank Math internal meta table
        $table_name = $wpdb->prefix . 'rank_math_internal_meta';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name) {
            $query = $wpdb->prepare("
                SELECT external_link_count 
                FROM {$table_name} 
                WHERE object_id = %d
            ", $post_id);
            
            $external_links = $wpdb->get_var($query);
            if ($external_links !== null && $external_links !== '') {
                return $external_links;
            }
        }
        
        // Fallback to post meta
        $link_keys = array(
            'rank_math_external_links',
            'rank_math_external_link_count',
            'rank_math_external_links_count',
            'rank_math_outlinks',
            'rank_math_backlinks'
        );
        
        foreach ($link_keys as $key) {
            $links = get_post_meta($post_id, $key, true);
            if ($links !== null && $links !== '') {
                return $links;
            }
        }
        
        return 0;
    }
    
    /**
     * Get Rank Math incoming links from database table with fallbacks
     */
    private function get_rank_math_incoming_links($post_id) {
        global $wpdb;
        
        // First try the Rank Math internal meta table
        $table_name = $wpdb->prefix . 'rank_math_internal_meta';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name) {
            $query = $wpdb->prepare("
                SELECT incoming_link_count 
                FROM {$table_name} 
                WHERE object_id = %d
            ", $post_id);
            
            $incoming_links = $wpdb->get_var($query);
            if ($incoming_links !== null && $incoming_links !== '') {
                return $incoming_links;
            }
        }
        
        // Fallback to post meta
        $link_keys = array(
            'rank_math_incoming_links',
            'rank_math_incoming_link_count',
            'rank_math_incoming_links_count',
            'rank_math_backlinks',
            'rank_math_internal_backlinks'
        );
        
        foreach ($link_keys as $key) {
            $links = get_post_meta($post_id, $key, true);
            if ($links !== null && $links !== '') {
                return $links;
            }
        }
        
        return 0;
    }
    
    /**
     * Debug method to check what Rank Math data is available
     */
    private function debug_rank_math_data($post_id) {
        global $wpdb;
        $debug_data = array();
        
        // Check Rank Math internal meta table
        $table_name = $wpdb->prefix . 'rank_math_internal_meta';
        $query = $wpdb->prepare("
            SELECT internal_link_count, external_link_count, incoming_link_count 
            FROM {$table_name} 
            WHERE object_id = %d
        ", $post_id);
        
        $link_data = $wpdb->get_row($query, ARRAY_A);
        if ($link_data) {
            $debug_data['INTERNAL_META_TABLE'] = $link_data;
        }
        
        // Check Rank Math analytics table
        $analytics_table = $wpdb->prefix . 'rank_math_analytics_objects';
        $analytics_query = $wpdb->prepare("
            SELECT id, created, title, page, object_type, object_subtype, object_id, primary_key, seo_score, schemas_in_use 
            FROM {$analytics_table} 
            WHERE object_id = %d
        ", $post_id);
        
        $analytics_data = $wpdb->get_row($analytics_query, ARRAY_A);
        if ($analytics_data) {
            $debug_data['ANALYTICS_TABLE'] = $analytics_data;
        }
        
        // Primary Rank Math meta keys (most important)
        $primary_keys = array(
            'rank_math_seo_score',
            'rank_math_focus_keyword',
            'rank_math_rich_snippet_type',
            'rank_math_internal_links',
            'rank_math_external_links',
            'rank_math_incoming_links'
        );
        
        // Secondary/alternative meta keys
        $secondary_keys = array(
            'rank_math_score',
            'rank_math_analytics_score',
            'rank_math_keyword',
            'rank_math_primary_keyword',
            'rank_math_target_keyword',
            'rank_math_schema_type',
            'rank_math_structured_data_type',
            'rank_math_rich_snippet',
            'rank_math_schema',
            'rank_math_schema_metadata',
            'rank_math_inlinks',
            'rank_math_outlinks',
            'rank_math_internal_link_count',
            'rank_math_external_link_count',
            'rank_math_incoming_link_count',
            'rank_math_backlinks',
            'rank_math_internal_backlinks',
            'rank_math_internal_links_count',
            'rank_math_external_links_count',
            'rank_math_incoming_links_count'
        );
        
        // Check primary keys first
        foreach ($primary_keys as $key) {
            $value = get_post_meta($post_id, $key, true);
            if (!empty($value)) {
                $debug_data['PRIMARY_' . $key] = $value;
            }
        }
        
        // Check secondary keys
        foreach ($secondary_keys as $key) {
            $value = get_post_meta($post_id, $key, true);
            if (!empty($value)) {
                $debug_data['SECONDARY_' . $key] = $value;
            }
        }
        
        // Also check Rank Math options
        $rank_math_options = get_option('rank_math_options', array());
        if (!empty($rank_math_options)) {
            $debug_data['RANK_MATH_OPTIONS'] = $rank_math_options;
        }
        
        return $debug_data;
    }
    
    /**
     * Escape CSV value
     */
    private function escape_csv_value($value) {
        // Handle numeric 0 values - they should show as "0" not empty
        if ($value === 0 || $value === '0') {
            return '0';
        }
        
        if (empty($value)) {
            return '';
        }
        
        // Remove any existing quotes and escape internal quotes
        $value = str_replace('"', '""', $value);
        
        // Wrap in quotes if contains comma, newline, or quote
        if (strpos($value, ',') !== false || strpos($value, "\n") !== false || strpos($value, '"') !== false) {
            $value = '"' . $value . '"';
        }
        
        return $value;
    }
}

// Initialize the plugin
new WP_Export_Rank_Math();
